void RotateSet   (int, int, int, int);
void RotateVector(double *, int);
void RotateBoundary (const Data *, RBox *, int, Grid *);
double RotateGet_ta(void);
double RotateGet_tb(void);




